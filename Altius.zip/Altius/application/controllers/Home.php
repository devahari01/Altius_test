<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->model('Home_model');
    }
	public function index()
	{
		if (isset($_POST['search']) and !empty($_POST['search'])) {
			$where = $_POST;
			$products['products'] = $this->Home_model->getAllProducts($where);
		}else{
			$products['products'] = $this->Home_model->getAllProducts();
		}
		$data = array_merge($products);
		$this->load->view('home',$data);
	}
}
