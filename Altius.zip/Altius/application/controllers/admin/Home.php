<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	public function __construct() {
        parent::__construct();
        $this->load->library('upload');
        $this->load->model('admin/Home_model');
    }
	

	public function index()
	{
		if (isset($_SESSION['username']) and !empty($_SESSION['username'])) {
			redirect('/admin/home/dashboard');
		}
		$this->load->view('admin/login');
	}
	public function checkLogin()
	{
		if($this->Home_model->checkLogin($_POST)){
			$_SESSION['username'] = $_POST['username'];
			print_r(1);
		}else{
			print_r("Invalid credentials");
		}
	}
	public function dashboard(){
		$this->load->view('admin/dashboard');
	}
	public function addProducts()
	{
		$this->load->view('admin/addproducrs');
	}
	public function logout()
	{
		$_SESSION['username'] = '';
		$this->load->view('admin/login');
	}
	
}