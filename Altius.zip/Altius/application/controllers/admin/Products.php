<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('upload');
		$this->load->model('admin/Products_model');
	}
	

	public function index()
	{
		$products['products'] = $this->Products_model->getAllProducts();
		$data = array_merge($products);
		$this->load->view('admin/products',$data);
	}
	public function addProducts()
	{
		$this->load->view('admin/addproducts');
	}
	public function edit($id)
	{
		$products['products'] = current($this->Products_model->getAProduct($id));
		$data = array_merge($products);
		$this->load->view('admin/editproducts',$data);
		
	}
	public function rand_string($length) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $size = strlen($chars);
        $str = '';
        for ($i = 0; $i < $length; $i++) {
            $str .= $chars[rand(0, $size - 1)];
        }
        return $str;
    }
	public function createProducts()
	{
		$filename = "Productd_" . date('dmyhis');
        $ext = pathinfo($_FILES['productimg']['name'], PATHINFO_EXTENSION);
        $filename = $filename. "." . $ext;
		$config = array(
			'upload_path' => $_SERVER['DOCUMENT_ROOT']."/Altius/assets/uploads/",
			'allowed_types' => "gif|jpg|png|jpeg",
			'overwrite' => TRUE,
			'max_size' => "2048000",
			'file_name' => $filename,
		);
		// print_r($_POST);
		// print_r($_FILES);
		// print_r($config);
		// print_r($_SERVER['DOCUMENT_ROOT']);
		// exit;
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload('productimg'))
		{
			$productArray = array(
				'name' => $_POST['name'],
				'price' => $_POST['price'],
				'description' => $_POST['description'],
				'image' => 'http://localhost/Altius/assets/uploads/'.$filename
			);
			do {
	                $productArray["sku"] = $this->rand_string(9);
	                $getsku = $this->Products_model->checksku($productArray["sku"]);
	            } while ($getsku > 0);
	        print_r($this->Products_model->createproducts($productArray));
		}else{
			print_r($this->upload->display_errors());
		}
	}
	public function updateProducts()
	{
		$filename = "Productd_" . date('dmyhis');
        $ext = pathinfo($_FILES['productimg']['name'], PATHINFO_EXTENSION);
        $filename = $filename. "." . $ext;
		$config = array(
			'upload_path' => $_SERVER['DOCUMENT_ROOT']."/Altius/assets/uploads/",
			'allowed_types' => "gif|jpg|png|jpeg",
			'overwrite' => TRUE,
			'max_size' => "2048000",
			'file_name' => $filename,
		);
		$this->load->library('upload', $config);
		$this->upload->initialize($config);
		if($this->upload->do_upload('productimg'))
		{
			$id = $_POST['id'];
			$productArray = array(
				'name' => $_POST['name'],
				'price' => $_POST['price'],
				'description' => $_POST['description'],
				'image' => 'http://localhost/Altius/assets/uploads/'.$filename
			);
	        print_r($this->Products_model->updateproducts($id,$productArray));
		}else{
			print_r($this->upload->display_errors());
		}
	}
	public function deleteProducts()
	{
		$id = $_POST['id'];
		print_r($this->Products_model->deleteproducts($id));
	}
}
