<?php

Class Home_model extends CI_Model {

    Public function __construct() {
        parent::__construct();
    }

    public function getAllProducts($where = []) {
        if (count($where)>0) {
            $getProducts = $this->db->select('*')->like('name',$where['search'])->get('products')->result_array();
        }else{
            $getProducts = $this->db->select('*')->get('products')->result_array();
        }
        return $getProducts;
    }
}

?>
