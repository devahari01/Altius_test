<?php

Class Home_model extends CI_Model {

    Public function __construct() {
        parent::__construct();
    }
    public function checkLogin($params) {
        $getUser = $this->db->select('*')->where('username', $params['username'])->where('password', $params['password'])->get('admin')->num_rows();
        return $getUser;
    }
}

?>
