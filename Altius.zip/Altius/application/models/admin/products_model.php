<?php

Class Products_model extends CI_Model {

    Public function __construct() {
        parent::__construct();
    }
    function rand_string($length) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $size = strlen($chars);
        $str = '';
        for ($i = 0; $i < $length; $i++) {
            $str .= $chars[rand(0, $size - 1)];
        }
        return $str;
    }
    public function getAllProducts() {
        $getProducts = $this->db->select('*')->get('products')->result_array();
        return $getProducts;
    }
    public function getAProduct($id) {
        $getProducts = $this->db->select('*')->where('id', $id)->get('products')->result_array();
        return $getProducts;
    }
    public function checksku($sku) {
        // print($sku);
        $getsku = $this->db->select('*')->where('sku', $sku)->get('products')->num_rows();
        return $getsku;
    }
    public function createproducts($params) {
        return $this->db->insert('products', $params);
    }
    public function updateproducts($id,$params) {
        return $this->db->where('id', $id)->update('products',$params);
    }
    public function deleteproducts($id) {
        return $this->db->where('id', $id)->delete('products');
    }
}

?>

