<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="<?php echo base_url('assets/admin/custom.css'); ?>">
</head>
<body>
<div class="wrapper fadeInDown">
  <div id="formContent">
  	<h1>ALTIUS</h1>
    <!-- Login Form -->
    <form name="login" id="login" action="" method="post" >
    	<div id="erormsg"></div>
      <input type="text" id="username" class="fadeIn second" name="username" placeholder="Username">
      <input type="Password" id="password" class="fadeIn third" name="password" placeholder="Password">
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="#">Forgot Password?</a>
    </div>

  </div>
</div>
</body>
<script>
	$(document).ready(function(){
	  $("#login").submit(function (e) {
	        window.scrollTo(0, 0);
	        e.preventDefault();
	        var data = $(this).serialize();
	        $.ajax({
	            url: "<?php echo base_url('admin/home/checkLogin');?>",
	            type: "POST",
	            data: data,
	            success: function (result)
	            {
	                if (result == 1)
	                {

	                    window.scrollTo(0, 0);
	                    //var userID = $.cookie("userID");
                        window.location.href = "<?php echo base_url('admin/home/dashboard')?>";

	                } else {
	                    window.scrollTo(0, 0);
	                    $('#erormsg').html(result);
	                    
	                }
	            },
	        });
	    })
	});
</script>
</html>