<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- <style type="text/css">
    @import url('https://fonts.googleapis.com/css2?family=Barlow&display=swap');

    body{
      font-family: 'Barlow', sans-serif;
    }

    a:hover{
      text-decoration: none;
    }

    .border-left{
      border-left: 2px solid var(--primary) !important;
    }


    .sidebar{
      top: 0;
      left : 0;
      z-index : 100;
      overflow-y: auto;
    }

    .overlay{
      background-color: rgb(0 0 0 / 45%);
      z-index: 99;
    }

    /* sidebar for small screens */
    @media screen and (max-width: 767px){
      
      .sidebar{
        max-width: 18rem;
        transform : translateX(-100%);
        transition : transform 0.4s ease-out;
      }
      
      .sidebar.active{
        transform : translateX(0);
      }
      
    }
  </style> -->
</head>
<body>
  <div class="container-fluid">
    <div class="row">
      <!-- sidebar -->
      <div class="col-md-3 col-lg-2 px-0 position-fixed h-100 bg-white shadow-sm sidebar" id="sidebar">
        <h1 class="text-primary d-flex my-4 justify-content-center">ALTIUS</h1>
        <div class="list-group rounded-0">
          <a href="<?php echo  base_url('admin/home')?>" class="list-group-item list-group-item-action active border-0 d-flex align-items-center">
            <span class="bi bi-border-all"></span>
            <span class="ml-2">Dashboard</span>
          </a>
          <a href="<?php echo  base_url('admin/products')?>" class="list-group-item list-group-item-action border-0 align-items-center">
            <span class="bi bi-box"></span>
            <span class="ml-2">Products</span>
          </a>
      </div>
    </div>
    <!-- overlay to close sidebar on small screens -->
    <div class="w-100 vh-100 position-fixed overlay d-none" id="sidebar-overlay"></div>
    <!-- note: in the layout margin auto is the key as sidebar is fixed -->
    <div class="col-md-9 col-lg-10 ml-md-auto px-0">
      <!-- top nav -->
      <nav class="w-100 d-flex px-4 py-2 mb-4 shadow-sm">
        <!-- close sidebar -->
        <button class="btn py-0 d-lg-none" id="open-sidebar">
          <span class="bi bi-list text-primary h3"></span>
        </button>
        <div class="ml-auto">
            <a href="<?php echo  base_url('admin/home/logout')?>"><button class="btn btn-danger">Logout</button></a>
          </div>
      </nav>
      <!-- main content -->
      <main class="container-fluid">
        <section class="row">
          <div class="col-md-6 col-lg-4">
            
            <article class="p-4 rounded shadow-sm border-left
            mb-4">
            <a href="#" class="d-flex align-items-center">
              <span class="bi bi-box h5"></span>
              <h5 class="ml-2">Products</h5>
            </a>
          </article>
        </div>
        <div class="col-md-6 col-lg-4">
          <article class="p-4 rounded shadow-sm border-left mb-4">
            <a href="#" class="d-flex align-items-center">
              <span class="bi bi-person h5"></span>
              <h5 class="ml-2">Customers</h5>
            </a>
          </article>
        </div>
        <div class="col-md-6 col-lg-4">
          <article class="p-4 rounded shadow-sm border-left mb-4">
            <a href="#" class="d-flex align-items-center">
              <span class="bi bi-person-check h5"></span>
              <h5 class="ml-2">Sellers</h5>
            </a>
          </article>
        </div>
      </section>

      <div class="jumbotron jumbotron-fluid rounded bg-white border-0 shadow-sm border-left px-4">
        <div class="container">
          <div class="row">
            <div class="col-md-10">
            <h6>Products List</h6>
            </div>
            <div class="col-md-2">
            <a href="./products/addproducts"><button class="btn btn-success float-right">Add Products</button></a>
            </div>
          </div>
          
          <div class="row">
            <div id="deleteproductwait_msg" class="alert alert-success no-border" style="font-size: 16px;display:none;">
                <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                <span class="text-semibold"><b>Please Wait! </b>Your data is validating</span>
              </div>
              <!-- Error Alert -->
              <div id="deleteproducterror_msg" class="alert alert-danger no-border" style="font-size: 16px;display:none;">
                <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                <span class="text-semibold"><b>Sorry! </b></span><span id="deleteproducterror_content"></span>
              </div>
              <div id="deleteproductsuccess_msg" class="alert alert-success no-border" style="font-size: 16px;display:none;">
                <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                <span class="text-semibold"><b>Success! </b></span><span id="deleteproductsuccess_content"></span>
              </div>
            <!-- <div class="col-sm-12"> -->
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Price</th>
                    <th scope="col">Sku</th>
                    <th scope="col">Description</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i = 1;
                  foreach ($products as $product) {
                    ?>
                    <tr>
                      <th scope="row"><?php echo $i;?></th>
                      <td><?php echo $product['name'];?></td>
                      <td><?php echo $product['price'];?></td>
                      <td><?php echo $product['sku'];?></td>
                      <td><?php echo $product['description'];?></td>
                      <td><a href="<?php echo  base_url('admin/products/edit/'.$product['id']);?>"><button class="btn btn-primary">Edit</button></a> | <button class="btn btn-danger" onclick="deleteProduct('<?php echo $product['id']?>')">Delete</button></td>
                    </tr>
                  <?php
                  $i++;
                    }
                  ?>
                  
                </tbody>
              </table>
            <!-- </div> -->
          </div>
        </div>
      </div>
    </main>
  </div>
</div>
</div>
<script src="<?php echo base_url('assets/admin/custom.js'); ?>"></script>
<script>
  function deleteProduct(id) {
    var id = id;
    window.scrollTo(0, 0);
    if(confirm("Are you sure you want to delete this product")){
      $('#deleteproductwait_msg').slideDown(1000);
      $.ajax({
          url: "<?php echo base_url('admin/products/deleteProducts');?>",
          type: "POST",
          data: {id:id},
          success: function (result)
          {
              if (result == 1)
              {

                  window.scrollTo(0, 0);
                  //var userID = $.cookie("userID");
                  window.location.href = "<?php echo base_url('admin/products');?>";
                  
              } else {
                  window.scrollTo(0, 0);
                  document.getElementById('deleteproducterror_content').innerHTML = result;
                  $('#deleteproductwait_msg').slideUp(1000);
                  $('#deleteproducterror_msg').slideDown(1000);
                  setTimeout(function () {
                  $('#deleteproducterror_msg').slideUp(1000);
                  }, 4000);
              }
          },
      });
    }
  }
</script>
</body>
</html>
