<?php header('Access-Control-Allow-Origin: *'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com - No Copyright -->
  <title>Altius</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/custom.css'); ?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  .card {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.10);
    transition: 0.3s;
    width: 40%;
    border-radius: 5px;
  }

  .card:hover {
    box-shadow: 0 8px 16px 0 rgba(0,0,0,0.10);
  }

  img {
    border-radius: 5px 5px 0 0;
  }

/*.container1 {
  padding: 2px 16px;
}*/
</style>
<body>

  <div class="jumbotron text-center">
    <h1>Altius</h1> 
    <form class="form-inline">
      <div class="input-group">
        <input type="product" class="form-control" size="50" placeholder="Search" required>
        <div class="input-group-btn">
          <button type="button" class="btn btn-danger">Search</button>
        </div>
      </div>
    </form>
  </div>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="<?php echo base_url('assets/s.jpg'); ?>" alt="Los Angeles" style="width:100%;">
      </div>

      <div class="item">
        <img src="<?php echo base_url('assets/s1.jpg'); ?>" alt="Chicago" style="width:100%;">
      </div>

      <div class="item">
        <img src="<?php echo base_url('assets/s3.jpeg'); ?>" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
  <div class="container">
    <div style="text-align: center;"><h3>Products List</h3></div>
    <div class="row">

      <?php
      foreach ($products as $product) { ?>
        <div class="col-md-4">
          <div class="card" style="width:300px">
            <img src="<?php echo $product['image'] ?>" alt="" style="width:100%">
            <div class="container">
              <h4><b><?php echo $product['name'] ?></b></h4>
              <h4><b><?php echo $product['price'] ?></b></h4>
              <p><?php echo $product['description'] ?></p>
            </div>
          </div>
        </div>
        <?php
      }
      ?>
    </div> 
  </div>
      <div class="jumbotron text-center" style="background: #007bff;">  
      <div class="row">  
        <div class="col-md-12">  
          <h1> ALTIUS </h1>  
          <footer class="footer">  
            <div class="container">  
              <div class="row">  
                <div class="col-md-3 m-b-30">  
                  <div class="footer-title m-t-5 m-b-20 p-b-8">  
                    About us  
                  </div>  
                  <p class="white-text">  
                    Lorem Ipsum.  
                  </p>  
                </div>  
                 
                <div class="col-md-3 m-b-30">  
                  <div class="footer-title m-t-5 m-b-20 p-b-8">  
                    Quick Links 
                  </div>  
                  <p class="white-text">  
                    Lorem Ipsum.  
                  </p>  
                </div> 
                <div class="col-md-3 m-b-30">  
                  <div class="footer-title m-t-5 m-b-20 p-b-8">  
                    Support
                  </div>  
                  <p class="white-text">  
                    Lorem Ipsum.  
                  </p>  
                </div> 
                <div class="col-md-3 m-b-30">  
                  <div class="footer-title m-t-5 m-b-20 p-b-8">  
                    Contact us 
                  </div>  
                  <p class="white-text">  
                    Lorem Ipsum.  
                  </p>  
                </div>  
              </div>  
            </div>  
          </footer>  
          <div class="footer-bottom">  
            Copyright ? 2022, All Rights Reserved  
          </div>  
        </div>  
      </div>  
    </div> 
  <!-- </div> -->

</body>
</html>
